export class JwtDTO {
    token: string;
    type: string;
    username: string;
    authorities: string[];
}