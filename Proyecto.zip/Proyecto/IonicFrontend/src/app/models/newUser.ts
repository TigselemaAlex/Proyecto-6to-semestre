export class NewUser {
    username: string;
    password: string;
    authorities: string[];
}