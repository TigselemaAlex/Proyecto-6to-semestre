import { Component, OnInit } from '@angular/core';
import { IonFab, MenuController } from '@ionic/angular';
import { Phone } from '../models/phone';
import { PhoneServicesService } from '../services/phone-services.service';
import { TokenService } from '../services/token.service';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  public phones: Phone[] = [];
  public isAdmin: boolean = false;
  public username: string;

  constructor(public menu: MenuController,
    private tokenService: TokenService,
    private phoneService: PhoneServicesService,
    private alertController: AlertController,
    private router: Router) {
    this.isAdmin = false;
  }


  loadAll(): void {
    this.phoneService.getAll().subscribe(
      {
        next: response => {
          this.phones = response;
        }, error: err => {
          console.log(err);
        }
      }
    );
  }

  ionViewWillEnter() {
    if (this.tokenService.getToken()) {
      this.username = this.tokenService.getUsername();
      this.tokenService.getAuthorities().find(auth => {
        if (auth == "ROLE_ADMIN") {
          this.isAdmin = true;
        }
      })

    } else {
      this.router.navigate(["/"]);
    }

    this.loadAll();
  }

  ionViewWillLeave() {
    this.isAdmin = false;
  }


  openFirst() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  openEnd() {
    this.menu.open('end');
  }

  openCustom() {
    this.menu.enable(true, 'custom');
    this.menu.open('custom');
  }

  onLogOut(): void {
    this.tokenService.logOut();
    this.router.navigate(["/"]);
  }

  async delete(id: number) {

    const alert = await this.alertController.create(
      {
        header: "Eliminar Celular",
        message: "¿Seguro que desea eliminar al celular?",
        buttons: [{
          text: "SI",
          handler: () => {
            this.phoneService.delete(id).subscribe({
              next: response => {
                this.loadAll();
              }, error: err => {
                console.log(err);
              }
            });
          }
        }, "No"]

      }
    );
    alert.present();

  }


}


