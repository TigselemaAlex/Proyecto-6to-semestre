import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Phone } from '../models/phone';
import { PhoneServicesService } from '../services/phone-services.service';
import { TokenService } from '../services/token.service';

@Component({
  selector: 'app-form-product',
  templateUrl: './form-product.page.html',
  styleUrls: ['./form-product.page.scss'],
})
export class FormProductPage implements OnInit {

  public phone: Phone = new Phone();
  public id: number;
  public title: string;
  constructor(private route: ActivatedRoute,
    private tokenService: TokenService,
    private router: Router,
    private phoneServices: PhoneServicesService,
    public toast: ToastController) {

  }

  ngOnInit() {

    if (this.tokenService.getToken()) {
      this.id = this.route.snapshot.params['id'];
      console.log(this.id);
      if (this.id) {
        this.title = "Editar Celular";
        this.loadPhone();
      } else {
        this.title = "Nuevo Celular";
      }
    } else {
      this.router.navigate(["/"]);
    }
  }


  loadPhone() {
    this.phoneServices.getById(this.id).subscribe({
      next: response => {
        this.phone = response;
        console.log(this.phone.brand);
      },
      error: err => {
        console.log(err);
      }
    });
  }

  save() {

    if (this.phone.id) {
      this.phoneServices.update(this.id, this.phone).subscribe({
        next: response => {
          this.presentToast("Celular actualizado con éxito", "primary");
          this.router.navigate(["/home"]);
        }, error: err => {
          console.log(err);
        }
      })
    } else {
      this.phoneServices.add(this.phone).subscribe({
        next: response => {
          this.presentToast("Celular agregado exitosamente.", "success");
          this.router.navigate(["/home"]);
        }
      });
    }
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toast.create({
      message: message,
      duration: 2000,
      color: color
    });
    toast.present();
  }

}
