import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { NewUser } from '../models/newUser';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {



  constructor(private authService: AuthService, private toast: ToastController, private router: Router) { }

  ngOnInit() {
  }

  newUser(username: any, password: any) {
    let newUser: NewUser = new NewUser();
    newUser.username = username.value;
    newUser.password = password.value;
    this.authService.newUser(newUser).subscribe({
      next: response => {
        this.presentToast("Usuario creado exitosamente", "success");
        this.router.navigate(['/login']);
      },
      error: err => {
        this.presentToast(err.error.message, "danger");
      }
    });
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toast.create({
      message: message,
      duration: 2000,
      color: color
    });
    toast.present();
  }

}
