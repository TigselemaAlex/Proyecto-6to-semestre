import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginUser } from '../models/loginUser';
import { AuthService } from '../services/auth.service';
import { TokenService } from '../services/token.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  isLogged = false;
  isLogginFail = false;
  loginUser: LoginUser;
  username: string;
  password: string;

  errorMessage: string;

  roles: string[] = [];
  constructor(private tokenService: TokenService, private authService: AuthService, private router: Router, public toast: ToastController) { }

  ngOnInit() {
    if (this.tokenService.getToken()) {
      this.isLogged = true;
      this.isLogginFail = false;
      this.roles = this.tokenService.getAuthorities();
      this.router.navigate(['/home']);
    }
  }

  ionViewWillEnter() {
    if (this.tokenService.getToken()) {
      this.isLogged = true;
      this.isLogginFail = false;
      this.roles = this.tokenService.getAuthorities();
      this.router.navigate(['/home']);
    }
  }


  onLogin(username: any, password: any): void {
    this.username = username.value;
    this.password = password.value;
    this.loginUser = new LoginUser(this.username, this.password);
    this.authService.login(this.loginUser).subscribe(
      {
        next: response => {
          this.isLogged = true;
          this.isLogginFail = false;
          this.tokenService.setToken(response.token);
          this.tokenService.setUsername(response.username);
          this.tokenService.setAuthorities(response.authorities);
          this.roles = response.authorities;
          this.router.navigate(['/home']);



        },
        error: err => {
          this.isLogged = false;
          this.isLogginFail = true;
          this.errorMessage = "No autorizado";
          this.presentToast(this.errorMessage);
        }
      }
    )
  }

  async presentToast(message: string) {
    const toast = await this.toast.create({
      message: message,
      duration: 2000,
      color: 'danger'
    });
    toast.present();
  }

}
