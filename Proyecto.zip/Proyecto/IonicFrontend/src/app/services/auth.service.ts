import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { JwtDTO } from '../models/jwt-DTO';
import { LoginUser } from '../models/loginUser';
import { NewUser } from '../models/newUser';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  authURL = "http://localhost:8085/api/auth/"

  constructor(private http: HttpClient) { }

  public newUser(newUser: NewUser): Observable<any> {
    return this.http.post<any>(`${this.authURL}new`, newUser);
  }

  public login(loginUser: LoginUser): Observable<JwtDTO> {
    return this.http.post<any>(`${this.authURL}login`, loginUser);
  }


}
