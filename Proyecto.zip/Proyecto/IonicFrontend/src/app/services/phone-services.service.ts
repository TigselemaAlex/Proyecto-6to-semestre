import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Phone } from '../models/phone';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PhoneServicesService {

  private URL: string = "http://localhost:8085/api/phones/";

  constructor(private http: HttpClient) { }

  getAll(): Observable<Phone[]> {
    return this.http.get<Phone[]>(this.URL);
  }

  getById(id: number): Observable<Phone> {
    return this.http.get<Phone>(`${this.URL}${id}`);
  }

  add(phone: Phone): Observable<Phone> {
    return this.http.post<Phone>(this.URL, phone);
  }

  update(id: number, phone: Phone): Observable<Phone> {
    return this.http.put<Phone>(`${this.URL}${id}`, phone);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.URL}${id}`);
  }


}
