package alex.sauriosoft.ionicbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IonicBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
