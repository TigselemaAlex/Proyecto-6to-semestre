package alex.sauriosoft.ionicbackend.controllers;

import alex.sauriosoft.ionicbackend.dtos.PhoneDTO;
import alex.sauriosoft.ionicbackend.entities.Phone;
import alex.sauriosoft.ionicbackend.service.PhoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/phones")
public class PhoneController {

    @Autowired
    private PhoneService phoneService;

    @GetMapping()
    public List<PhoneDTO> getAll(){
        return phoneService.getAll().stream().map(PhoneDTO::from).collect(Collectors.toList());
    }

    @GetMapping("{id}")
    public PhoneDTO getById(@PathVariable final Long id){
        try {
            return PhoneDTO.from(phoneService.getById(id));
        }catch (Exception ex){
            throw new RuntimeException();
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public PhoneDTO addPhone(@RequestBody final PhoneDTO phoneDTO){
        try {
            return PhoneDTO.from(phoneService.addPhone(Phone.from(phoneDTO)));
        }catch (Exception ex){
            throw new RuntimeException();
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("{id}")
    public PhoneDTO updatePhoneById(@PathVariable final Long id, @RequestBody final PhoneDTO phoneDTO){
        try {
            return PhoneDTO.from(phoneService.updatePhoneById(Phone.from(phoneDTO), id));
        }catch (Exception ex){
            throw new RuntimeException();
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("{id}")
    public boolean deletePhoneById(@PathVariable final Long id){
        try {
            return phoneService.deletePhoneById(id);
        }catch (Exception ex){
            throw new RuntimeException();
        }
    }

}
