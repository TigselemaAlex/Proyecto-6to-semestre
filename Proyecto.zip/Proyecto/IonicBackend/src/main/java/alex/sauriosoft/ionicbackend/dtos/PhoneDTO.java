package alex.sauriosoft.ionicbackend.dtos;

import alex.sauriosoft.ionicbackend.entities.Phone;
import lombok.*;

import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PhoneDTO {

    private Long id;

    private  String brand;

    private String model;

    private Double price;

    private String description;

    private Date lastModification;

    public static PhoneDTO from(Phone phone){
        return PhoneDTO.builder()
                .id(phone.getId())
                .brand(phone.getBrand())
                .model(phone.getModel())
                .price(phone.getPrice())
                .description(phone.getDescription())
                .lastModification(phone.getLastModification())
                .build();
    }
}
