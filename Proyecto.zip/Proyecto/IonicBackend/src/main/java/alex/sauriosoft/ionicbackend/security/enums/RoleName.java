package alex.sauriosoft.ionicbackend.security.enums;

public enum RoleName {
    ROLE_ADMIN, ROLE_USER
}
