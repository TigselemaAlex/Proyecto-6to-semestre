package alex.sauriosoft.ionicbackend.entities;

import alex.sauriosoft.ionicbackend.dtos.PhoneDTO;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Phone {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50, nullable = false)
    private  String brand;

    @Column(length = 50, nullable = false)
    private String model;

    @Column(nullable = false)
    private Double price;

    @Column(length = 120)
    private String description;

    @Column
    private Date lastModification;

    @PrePersist
    public void insertDate(){
        lastModification = new Date();
    }


    public static Phone from (PhoneDTO phoneDTO){
        return Phone.builder()
                .brand(phoneDTO.getBrand())
                .description(phoneDTO.getDescription())
                .model(phoneDTO.getModel())
                .price(phoneDTO.getPrice())
                .build();
    }

}
