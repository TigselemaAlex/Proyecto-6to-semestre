package alex.sauriosoft.ionicbackend.service;

import alex.sauriosoft.ionicbackend.entities.Phone;
import alex.sauriosoft.ionicbackend.repository.PhoneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
public class PhoneService {

    @Autowired
    private PhoneRepository phoneRepository;

    public List<Phone> getAll(){
        return phoneRepository.findAll();
    }

    public Phone getById(Long id){
        return phoneRepository.findById(id).orElse(null);
    }

    public Phone addPhone(Phone phone){
        return phoneRepository.save(phone);
    }

    public Phone updatePhoneById(Phone phone, Long id){
        Phone phoneToUpdate = getById(id);
        if(Objects.isNull(phoneToUpdate)){
            return null;
        }
        phoneToUpdate.setBrand(phone.getBrand());
        phoneToUpdate.setDescription(phone.getDescription());
        phoneToUpdate.setModel(phone.getModel());
        phoneToUpdate.setPrice(phone.getPrice());
        phoneToUpdate.setLastModification(new Date());
        return phoneToUpdate;
    }

    public boolean deletePhoneById(Long id){
        Phone phoneToDelete = getById(id);
        if(Objects.nonNull(phoneToDelete)){
            phoneRepository.delete(phoneToDelete);
            return true;
        }
        return false;
    }

}
