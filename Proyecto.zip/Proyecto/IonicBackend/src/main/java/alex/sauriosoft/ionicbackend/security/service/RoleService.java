package alex.sauriosoft.ionicbackend.security.service;

import alex.sauriosoft.ionicbackend.security.entities.Role;
import alex.sauriosoft.ionicbackend.security.enums.RoleName;
import alex.sauriosoft.ionicbackend.security.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;


    public Optional<Role> getByRole(RoleName roleName){
        return roleRepository.findByRole(roleName);
    }

    public void save (Role role){
        roleRepository.save(role);
    }


}
